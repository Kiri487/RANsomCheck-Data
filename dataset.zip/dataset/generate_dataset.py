import numpy as np

## the whole dataset is too big, use the demo dataset
dataset1 = np.load('./data_demo_goodware.npz', allow_pickle=True)
dataset2 = np.load('./ransomware_dataset.npz', allow_pickle=True)

## merge the dataset
merged_data = {}

for key in dataset1.keys():
    # print(key)
    max_length = max(len(dataset1[key][0]), len(dataset2[key][0]))
    dataset1_padded = np.pad(dataset1[key], (0, max_length - len(dataset1[key][0])), 'constant', constant_values=(0,))
    dataset2_padded = np.pad(dataset2[key], (0, max_length - len(dataset2[key][0])), 'constant', constant_values=(0,))
    merged_data[key] = np.concatenate((dataset1_padded, dataset2_padded))
    # print(merged_data[key])

# random the dataset
indices = np.arange(len(merged_data['x_name']))
np.random.shuffle(indices)

for key in merged_data.keys():
    merged_data[key] = merged_data[key][indices]
    # print(merged_data[key])

## split the dataset
dataset_train = {}
dataset_test = {}
dataset_train_length = int(0.7 * len(merged_data['x_name']))
dataset_test_length = len(merged_data['x_name']) - dataset_train_length
for key in merged_data.keys():
  dataset_train[key] = merged_data[key][:dataset_train_length]
  dataset_test[key] = merged_data[key][dataset_train_length:]

np.savez('./report_dataset_train.npz', x_name = dataset_train['x_name'], x_semantic = dataset_train['x_semantic'], y = dataset_train['y'])
np.savez('./report_dataset_test.npz', x_name = dataset_test['x_name'], x_semantic = dataset_test['x_semantic'], y = dataset_test['y'])


