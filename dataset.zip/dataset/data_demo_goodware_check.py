import numpy as np

data = np.load('./report_dataset_test.npz')

y = data['y']

if_all_zeros = np.all(y == 0)

if if_all_zeros:
    print("All are goodware!")
else:

    print("There are some malware...")

num_samples = len(y)
print("conut: {}".format(num_samples))